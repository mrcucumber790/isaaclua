#!/usr/bin/env python3
"""Cut a binary BMFont (.fnt v3, Isaac's fonts) down to the characters a page needs and repack them in one
small texture: REP+'s TeamMeatEx12 holds 46k characters on three 2048x2048 pages (48 MB of texture); the
My Stuff page writes English (and Cyrillic for names) only.

Usage: python3 -I crop_font.py <in.fnt> <out.fnt>   (pages are read next to in.fnt, written next to out.fnt)
"""
import struct
import sys
from pathlib import Path

from PIL import Image

KEEP = [(0x20, 0x250), (0x370, 0x530), (0x2000, 0x2070), (0x20a0, 0x20c0), (0x2190, 0x21a0), (0xfffd, 0xfffe)]


def main(src, dst):
    src, dst = Path(src), Path(dst)
    d = src.read_bytes()
    assert d[:4] == b"BMF\x03"
    blocks, i = {}, 4
    while i < len(d):
        t, n = struct.unpack_from("<BI", d, i)
        blocks[t] = d[i + 5:i + 5 + n]
        i += 5 + n
    pages = [p.decode() for p in blocks[3].split(b"\0") if p]
    imgs = [Image.open(src.parent / p).convert("RGBA") for p in pages]
    chars = []
    for k in range(len(blocks[4]) // 20):
        c = list(struct.unpack_from("<IHHHHhhhBB", blocks[4], k * 20))
        if any(a <= c[0] < b for a, b in KEEP):
            chars.append(c)
    # shelf packing into a 512-wide atlas
    W, x, y, row = 512, 0, 0, 0
    placed = []
    for c in sorted(chars, key=lambda c: -c[4]):
        w, h = c[3], c[4]
        if x + w + 1 > W:
            x, y, row = 0, y + row + 1, 0
        placed.append((c, x, y))
        x += w + 1
        row = max(row, h)
    H = 1
    while H < y + row + 1:
        H *= 2
    atlas = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out_chars = b""
    for c, px, py in sorted(placed, key=lambda t: t[0][0]):
        cid, cx, cy, w, h, xo, yo, xa, page, chan = c
        if w and h:
            atlas.paste(imgs[page].crop((cx, cy, cx + w, cy + h)), (px, py))
        out_chars += struct.pack("<IHHHHhhhBB", cid, px, py, w, h, xo, yo, xa, 0, chan)
    keep = {c[0] for c in chars}
    kern = b""
    for k in range(len(blocks.get(5, b"")) // 10):
        a, b, amt = struct.unpack_from("<IIh", blocks[5], k * 10)
        if a in keep and b in keep:
            kern += struct.pack("<IIh", a, b, amt)
    page_name = dst.stem + "_0.png"
    atlas.save(dst.parent / page_name)
    common = bytearray(blocks[2])
    struct.pack_into("<HHH", common, 4, W, H, 1)
    out = b"BMF\x03"
    for t, body in ((1, blocks[1]), (2, bytes(common)), (3, page_name.encode() + b"\0"), (4, out_chars), (5, kern)):
        if t == 5 and not body:
            continue
        out += struct.pack("<BI", t, len(body)) + body
    dst.write_bytes(out)
    print("%s: %d chars, %dx%d" % (dst.name, len(chars), W, H))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
