#!/usr/bin/env python3
"""Fill the isaac-repplus mod with the Repentance+ game files it uses (sounds, sprites, animations, a font),
taken from YOUR OWN copy of The Binding of Isaac: Repentance+ on PC. The public release does not carry these
files, because they belong to the game.

1. On the PC, extract the game's files with the game's own tool:
   <Steam>/steamapps/common/The Binding of Isaac Rebirth/tools/ResourceExtractor/ResourceExtractor.exe
   It writes them to <game folder>/extracted_resources/resources.
2. python3 get_assets.py <game folder>/extracted_resources <the isaac-repplus mod folder>
   (the mod folder is atmosphere/contents/010021C000B6A000/romfs/mods/isaac-repplus from the zip).
   The font for the My Stuff pause page needs Pillow (pip install pillow); without it that one step is skipped.
3. Copy the mod folder to the SD card (or the whole atmosphere folder, as in the README).

Each file is compared with the file the mod was tested with (assets.tsv next to this script). A file from
another REP+ version is still used, with a warning.
"""
import hashlib
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent


def find(root, rel):
    """rel under root, ignoring case (the extractor and the game do not agree on case)."""
    p = root
    for part in rel.split('/'):
        q = p / part
        if not q.exists():
            low = part.lower()
            hit = [c for c in (os.listdir(p) if p.is_dir() else []) if c.lower() == low]
            if not hit:
                return None
            q = p / hit[0]
        p = q
    return p


def font(root, mod):
    """My Stuff font: REP+'s TeamMeatEx12 cut to Latin/Cyrillic (crop_font.py), 48 MB of texture -> 128 KB."""
    fnt = find(root, 'resources/font/teammeatex/teammeatex12.fnt')
    if fnt is None:
        print('missing: resources/font/teammeatex/teammeatex12.fnt')
        return False
    try:
        import PIL  # noqa: F401
    except ImportError:
        print('font skipped: Pillow is not installed (pip install pillow)')
        return False
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        (t / 'TeamMeatEx12.fnt').write_bytes(fnt.read_bytes())
        for i in range(3):
            page = find(fnt.parent, 'teammeatex12_%d.png' % i)
            if page is None:
                print('missing:', fnt.parent / ('teammeatex12_%d.png' % i))
                return False
            (t / ('TeamMeatEx12_%d.png' % i)).write_bytes(page.read_bytes())
        out = mod / 'resources/font/repplus'
        out.mkdir(parents=True, exist_ok=True)
        subprocess.run([sys.executable, '-I', str(HERE / 'crop_font.py'), str(t / 'TeamMeatEx12.fnt'),
                        str(out / 'mystuff12.fnt')], check=True)
    return True


def main(argv):
    if len(argv) != 2:
        print(__doc__)
        return 2
    root, mod = Path(argv[0]), Path(argv[1])
    if root.name.lower() == 'resources' and not (root / 'resources').is_dir():
        root = root.parent
    if not (mod / 'main.lua').is_file():
        print('not the isaac-repplus mod folder (no main.lua):', mod)
        return 2
    ok = warn = miss = 0
    for line in (HERE / 'assets.tsv').read_text(encoding='utf-8').splitlines():
        if not line or line.startswith('#'):
            continue
        cols = line.split('\t')
        sha, dst, rel = cols[:3]
        f = find(root, rel)
        if f is None:
            print('missing:', rel)
            miss += 1
            continue
        data = f.read_bytes()
        if len(cols) > 3 and cols[3]:
            for pair in cols[3].split(' || '):
                old, new = pair.split(' => ')
                data = data.replace(old.encode(), new.encode())
        out = mod / dst
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        if hashlib.sha256(data).hexdigest()[:16] not in sha.split(","):
            print('different version:', rel)
            warn += 1
        else:
            ok += 1
    fo = font(root, mod)
    print('%d files copied (%d differ from the tested REP+ version), %d missing, font %s'
          % (ok + warn, warn, miss, 'done' if fo else 'NOT done'))
    return 1 if miss else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
