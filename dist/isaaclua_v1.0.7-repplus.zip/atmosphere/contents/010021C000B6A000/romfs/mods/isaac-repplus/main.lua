-- isaac-repplus: Repentance+ item behaviour on Switch 1.7.9b, written against the PC modding API (isaaclua).
-- Item numbers, pools and cache flags come from repplus_data.lua via the isaaclua build; this file holds
-- the changes that need code. Only changes whose numbers are known exactly are here (CHANGES.md).
local mod = RegisterMod("isaac-repplus", 1)
local game = Game()

local FLUSH = CollectibleType.COLLECTIBLE_FLUSH or 291
local LOUSE = TrinketType.TRINKET_LOUSE or 70
local USED_DIAPER = TrinketType.TRINKET_USED_DIAPER or 93
local MISSING_POSTER = TrinketType.TRINKET_MISSING_POSTER or 23

local function players()
  local t = {}
  for i = 0, game:GetNumPlayers() - 1 do t[#t + 1] = Isaac.GetPlayer(i) end
  return t
end

-- 2Spooky, Odd Mushroom (Thin) and Equality!'s tears are added natively inside EvaluateItems at REP+'s places
-- (src/repplus_hooks.inc); Lazy Worm's damage and the Equality re-evaluation are in the loader's repplus.lua.

-- Short Fuse's +15 / +30 / +50 bomb damage is in the loader's repplus.lua (REP+ 0x781d41)

-- Louse (REP+ Entity_Player room clear 0x7a97b7): one blue spider per holder when a room is cleared
-- (HasTrinket, so a golden Louse gives one too; 1.7.9b's own Louse spiders during the fight stay as they are)
mod:AddCallback(ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, function()
  for _, p in ipairs(players()) do
    if p:HasTrinket(LOUSE) then p:AddBlueSpider(p.Position) end
  end
end)

-- Used Diaper: a blue fly on entering an uncleared combat room
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, function()
  local room = game:GetRoom()
  if room:IsClear() or room:GetAliveEnemiesCount() == 0 then return end
  for _, p in ipairs(players()) do
    local n = p:GetTrinketMultiplier(USED_DIAPER)
    if n > 0 then p:AddBlueFlies(n, p.Position, nil) end
  end
end)

-- Missing Poster (REP+ Entity_Player::TriggerNewStage 0x7a5c18..0x7a5d0a): on every new floor each holder rolls
-- his trinket RNG, Random(100) < 33 / 66 / 100 at multiplier 1 / 2 / 3+, and on success the Super Secret Room's
-- map icon is shown (DisplayFlags | 4)
mod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, function()
  local level = game:GetLevel()
  for _, p in ipairs(players()) do
    local m = p:GetTrinketMultiplier(MISSING_POSTER)
    if m > 0 then
      local chance = m >= 3 and 100 or m == 2 and 66 or 33
      if p:GetTrinketRNG(MISSING_POSTER):RandomInt(100) < chance then
        local rooms = level:GetRooms()
        for i = 0, rooms.Size - 1 do
          local d = rooms:Get(i)
          if d.Data and d.Data.Type == RoomType.ROOM_SUPERSECRET then
            local desc = level:GetRoomByIdx(d.SafeGridIndex)
            desc.DisplayFlags = desc.DisplayFlags | 4
            break
          end
        end
        level:UpdateVisibility()
      end
    end
  end
end)

-- Flush!: also kills Turdlets
mod:AddCallback(ModCallbacks.MC_USE_ITEM, function()
  for _, e in ipairs(Isaac.FindByType(EntityType.ENTITY_TURDLET or 918)) do e:Kill() end
end, FLUSH)

-- Dead Bird (REP+ Entity_Player::update_effects 0x79d0c6): The Lost and Tainted Lost (not as a co-op ghost)
-- keep Dead Bird's effect on all the time, as 1.7.9b already does for Eve with Birthright
mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, function(_, p)
  local t = p:GetPlayerType()
  if (t ~= PlayerType.PLAYER_THELOST and t ~= PlayerType.PLAYER_THELOST_B) or p:IsCoopGhost() then return end
  if not p:HasCollectible(CollectibleType.COLLECTIBLE_DEAD_BIRD, false) then return end
  local te = p:GetEffects()
  if not te:HasCollectibleEffect(CollectibleType.COLLECTIBLE_DEAD_BIRD) then
    te:AddCollectibleEffect(CollectibleType.COLLECTIBLE_DEAD_BIRD, true, 1)
  end
end)

-- Dead Bird (REP+ TemporaryEffects::ClearEffects 0x930c1d): on a room change the effect stays while the
-- player (not a co-op ghost) has at most 1 health (Eve 2), counted as bone + soul hearts + red hearts
-- (red only with heart containers). The game clears it first, so it is put back on the new room.
local dead_bird_on = {}
mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, function(_, p)
  -- remembered until the new room has handled it (the player can update in it before MC_POST_NEW_ROOM)
  if p:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_DEAD_BIRD) then
    dead_bird_on[GetPtrHash(p)] = true
  elseif game:GetRoom():GetFrameCount() > 1 then
    dead_bird_on[GetPtrHash(p)] = nil
  end
end)
mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM, function()
  for _, p in ipairs(players()) do
    local h = GetPtrHash(p)
    if dead_bird_on[h] and not p:IsCoopGhost() then
      local hp = p:GetBoneHearts() + p:GetSoulHearts() + (p:GetMaxHearts() > 0 and p:GetHearts() or 0)
      local limit = p:GetPlayerType() == PlayerType.PLAYER_EVE and 2 or 1
      local te = p:GetEffects()
      if hp <= limit and not te:HasCollectibleEffect(CollectibleType.COLLECTIBLE_DEAD_BIRD) then
        te:AddCollectibleEffect(CollectibleType.COLLECTIBLE_DEAD_BIRD, true, 1)
      end
    end
    dead_bird_on[h] = nil
  end
end)

-- Pageant Boy (REP+ Entity_Player::AddCollectible case 141, 0x7603b1): on the first pickup, besides the 7
-- coins, a penny trinket picked at random among the available ones of Butt, Bloody, Burnt, Flat,
-- Counterfeit, Rotten, Blessed, Charged and Cursed Penny. The game's 7 coins (spawner = the player, spawned
-- this frame) tell the first pickup apart from a later one.
local PENNIES = {24, 49, 50, 51, 52, 126, 131, 147, 172}
local pageant_num = {}
mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, function(_, p)
  local h = GetPtrHash(p)
  local n = p:GetCollectibleNum(CollectibleType.COLLECTIBLE_PAGEANT_BOY, true)
  local before = pageant_num[h]
  pageant_num[h] = n
  if not before or n <= before then return end
  local coins = 0
  for _, e in ipairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_COIN)) do
    if e.FrameCount <= 1 and e.SpawnerEntity and GetPtrHash(e.SpawnerEntity) == h then coins = coins + 1 end
  end
  if coins < 7 then return end
  local list, cfg = {}, Isaac.GetItemConfig()
  for _, id in ipairs(PENNIES) do
    local t = cfg:GetTrinket(id)
    if t and t:IsAvailable() then list[#list + 1] = id end
  end
  if #list == 0 then return end
  local rng = p:GetCollectibleRNG(CollectibleType.COLLECTIBLE_PAGEANT_BOY)
  local id = list[rng:RandomInt(#list) + 1]
  local pos = game:GetRoom():FindFreePickupSpawnPosition(p.Position, 40, true)
  Isaac.Spawn(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_TRINKET, id, pos, Vector(0, 0), p)
end)
